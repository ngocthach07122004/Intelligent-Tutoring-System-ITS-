package ITS.com.vn.course_service.security;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.Authentication;

/**
 * Utility helpers for extracting user context from Authentication/JWT.
 */
public final class SecurityUtils {

    private static final Logger log = LoggerFactory.getLogger(SecurityUtils.class);

    private SecurityUtils() {
    }

    public static String getUserId(Authentication authentication) {
        return getUserId(authentication, false);
    }

    public static String getUserId(Authentication authentication, boolean required) {
        if (authentication != null) {
            Object principal = authentication.getPrincipal();
            if (principal instanceof String userIdStr) {
                return userIdStr;
            }
            String name = authentication.getName();
            if (name != null && !name.isBlank()) {
                return name;
            }
        }

        if (required) {
            throw new RuntimeException("Unable to extract user ID from authentication");
        }
        return null;
    }

    // Deprecated: Use getUserId instead as User IDs are now UUID strings
    public static Long getUserIdAsLong(Authentication authentication) {
        return getUserIdAsLong(authentication, false);
    }

    // Deprecated: Use getUserId instead as User IDs are now UUID strings
    public static Long getUserIdAsLong(Authentication authentication, boolean required) {
        String userId = getUserId(authentication, required);
        if (userId == null) {
            return null;
        }
        try {
            return Long.parseLong(userId);
        } catch (NumberFormatException ex) {
            log.warn("User id in JWT is not numeric: {}", userId);
            // Fallback for legacy support or return null if not numeric
            if (required) {
                // If required and not numeric, we might want to throw exception OR
                // if we are transitioning, maybe we should just return null and let the caller
                // handle it?
                // But for now, let's throw to be safe if it's strictly required as Long.
                // However, since we are migrating to String, callers should stop using this.
                throw new RuntimeException("User ID in token is not numeric: " + userId);
            }
            return null;
        }
    }
}
