package ITS.com.vn.course_service.domain.enums;

public enum EnrollmentStatus {
    ACTIVE, // Đang học
    COMPLETED, // Đã hoàn thành
    DROPPED // Đã bỏ học
}
