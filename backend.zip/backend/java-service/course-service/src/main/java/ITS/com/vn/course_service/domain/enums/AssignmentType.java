package ITS.com.vn.course_service.domain.enums;

public enum AssignmentType {
    PROJECT,
    UPLOAD
}
