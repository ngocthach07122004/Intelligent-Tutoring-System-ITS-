package ITS.com.vn.course_service.domain.enums;

public enum CourseStatus {
    DRAFT,
    PUBLISHED,
    ARCHIVED
}
