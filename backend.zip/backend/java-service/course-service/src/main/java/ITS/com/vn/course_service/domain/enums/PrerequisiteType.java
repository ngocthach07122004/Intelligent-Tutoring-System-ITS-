package ITS.com.vn.course_service.domain.enums;

public enum PrerequisiteType {
    HARD, // Required
    SOFT // Recommended
}
