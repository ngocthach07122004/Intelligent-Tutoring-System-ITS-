package ITS.com.vn.course_service.domain.enums;

public enum LessonType {
    VIDEO,
    TEXT,
    QUIZ
}
