package ITS.com.vn.course_service.domain.enums;

public enum VersionStatus {
    DRAFT,
    REVIEW,
    PUBLISHED,
    ARCHIVED
}
