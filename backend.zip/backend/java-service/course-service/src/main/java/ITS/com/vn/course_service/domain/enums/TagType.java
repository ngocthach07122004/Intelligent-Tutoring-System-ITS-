package ITS.com.vn.course_service.domain.enums;

public enum TagType {
    TOPIC,
    SKILL,
    DIFFICULTY
}
