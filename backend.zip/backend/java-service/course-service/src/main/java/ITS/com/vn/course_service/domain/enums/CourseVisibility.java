package ITS.com.vn.course_service.domain.enums;

public enum CourseVisibility {
    PUBLIC,
    PRIVATE
}
