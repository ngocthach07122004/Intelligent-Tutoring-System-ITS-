package ITS.com.vn.dashboard_service.dto.client;

import lombok.Data;

@Data
public class UserProfileDTO {
    private String timezone;
    private String learningStyle;
}
