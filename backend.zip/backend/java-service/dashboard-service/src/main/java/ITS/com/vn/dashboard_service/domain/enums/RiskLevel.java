package ITS.com.vn.dashboard_service.domain.enums;

public enum RiskLevel {
    LOW,
    MEDIUM,
    HIGH
}
