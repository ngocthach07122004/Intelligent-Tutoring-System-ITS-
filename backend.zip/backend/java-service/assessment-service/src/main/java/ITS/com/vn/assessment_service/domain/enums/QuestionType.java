package ITS.com.vn.assessment_service.domain.enums;

public enum QuestionType {
    MCQ,
    CODING,
    ESSAY
}
