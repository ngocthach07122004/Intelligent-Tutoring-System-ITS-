package ITS.com.vn.assessment_service.domain.enums;

public enum AttemptStatus {
    IN_PROGRESS,
    SUBMITTED,
    UNDER_REVIEW,
    GRADED
}
