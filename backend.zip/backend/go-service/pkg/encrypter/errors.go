package encrypter

import "errors"

var (
	ErrExpireCode = errors.New("expire code")
)
