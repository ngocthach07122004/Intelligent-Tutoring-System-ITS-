package cron

const tz = "Asia/Ho_Chi_Minh"
