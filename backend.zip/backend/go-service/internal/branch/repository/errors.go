package repository

import "errors"

var (
	ErrNotFound = errors.New("branch not found")
)
