package models

// Scope is the scope of data.
type Scope struct {
	UserID string `json:"user_id"`
	ShopID string `json:"shop_id"`
}
