package repository

import "errors"

var (
	ErrNotFound = errors.New("department not found")
)
