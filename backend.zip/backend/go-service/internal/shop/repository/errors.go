package repository

import "errors"

var (
	ErrNotFound = errors.New("shop not found")
)